package co.edu.uceva.pais_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaisServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
